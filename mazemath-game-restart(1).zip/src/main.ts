document.getElementById('app')!.innerHTML = `
  <h1>🎮 Arithmetic Maze Game</h1>
  <p>Click the correct number to go through the maze!</p>
`;