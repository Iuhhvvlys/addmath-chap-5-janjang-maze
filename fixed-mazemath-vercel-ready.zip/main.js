import './style.css';
document.getElementById('app').innerText = 'Maze Math Game Loaded!';